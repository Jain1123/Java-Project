package com.cestar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



import com.cestar.modelb.Employee;



public class EmpDao {
	
	public Connection getConnection() {

		String url = "jdbc:mysql://localhost:3306/libraryrecords?useSSL=false";

		String user = "root";

		String pwd = "toor";

		Connection con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection(url, user, pwd);

			System.out.println("Connection successfull:");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}

	public List<Employee> displayAllEmployees() {

		List<Employee> library_users = new ArrayList<>();

		String sql = "select * from library_users ";

		Connection con = getConnection();

		try {
			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				int id = rs.getInt(1);

				String name = rs.getString(2);

				String contact = rs.getString(3);

				String book_issued = rs.getString(4);

				String date_issued = rs.getString(5);
				String date_returned= rs.getString(6);   

				Employee emp = new Employee(id, name, contact,book_issued,date_issued,date_returned);

				library_users .add(emp);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(library_users );

		return library_users ;

	}
	
	public void deleteEmployee(int empIdTobeDeleted){
		
		Connection con = getConnection();
		
		String sql = "delete  from library_users  where id=?;";
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, empIdTobeDeleted);
			
			int status = pstmt.executeUpdate();
			
			if(status>0){
				System.out.println("Employee Deleted");
			}
			else {
				
				System.out.println("Try again dear:");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void insertEmployee(Employee emp){
		
		
		Connection con = getConnection();
		
		String sql = "insert into library_users s values(?,?,?,?,?,?)";
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1,emp.getId());
			
			pstmt.setString(2,emp.getName());
			
			pstmt.setString(3,emp.getContact());
			
			pstmt.setString(4,emp.getBook_issued());
			
			pstmt.setString(5,emp.getDate_issued());
			pstmt.setString(6,emp.getDate_returned());
			int status = pstmt.executeUpdate();
			
			if(status>0){
				
				System.out.println("Record Inserted successfully:");
			}
			else {
				
				System.out.println("Record not Inserted:");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	
	public Employee getEmployeeById(int curr_id){
		
		
		Connection con = getConnection();
		
		String sql = "select * from library_users  where id=?;";
		
		Employee   emp = new Employee();
		
		try {
			
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, curr_id);
			
			ResultSet rs =    pstmt.executeQuery();
			
			while(rs.next()){
				
				int id = rs.getInt(1);
				
				String name = rs.getString(2);
				
				String contact = rs.getString(3);
				
				String book_issued= rs.getString(4);
				
				String date_issued = rs.getString(5);
				String date_returned = rs.getString(6);
				
				emp.setId(id);
				emp.setName(name);
				emp.setContact(contact);
				emp.setBook_issued(book_issued);
				emp.setDate_issued(date_issued);
				emp.setDate_returned(date_returned);
				
				
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
		
		
		
		
	}
	
	public void updateEmployee(int curr_id,Employee updated_emp){
		
		
		Connection con = getConnection();
		
		String sql = "update library_users  set id=? , name =? ,contact=? , book_issued=? ,date_issued =?,date_returned =? where id=?";
		
	//	"update employees set id=? , name =? ,city=? , department=? ,email =? where id=?"
		
		try {
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1,updated_emp.getId());
			
			pstmt.setString(2,updated_emp.getName());
			
			pstmt.setString(3,updated_emp.getContact());
			
			pstmt.setString(4,updated_emp.getBook_issued());
			
			pstmt.setString(5,updated_emp. getDate_issued());
			pstmt.setString(6,updated_emp. getDate_returned()); 
			
			pstmt.setInt(7,curr_id);
			
			int status = pstmt.executeUpdate();
			
			if(status>0){
				
				System.out.println("Record Updated:");
			}
			else {
				
				System.out.println("Try again:");
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

	
	

}


package com.cestar.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import com.cestar.dao.EmpDao;
import com.cestar.modelb.Employee;

@ManagedBean(name = "con")
@SessionScoped
public class Controller {

	EmpDao obj = new EmpDao();
	int old_id = 0 ;

	public List<Employee> display() {

		List<Employee> libraryrecords = new ArrayList<>();

		return libraryrecords = obj.displayAllEmployees();

	}
	
	public String edit(int id) {
		
		
		old_id = id ;
		Employee emp = obj.getEmployeeById(id);
		
//		Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		
		
		Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		
		sessionMap.put("library_users ",emp );
		
		return "update" ;
		
		
	}
	
	public String update(Employee emp) {
		
		obj.updateEmployee(old_id,emp );
		
		return "index";
	}
	
	public String delete(int eid) {
		
		obj.deleteEmployee(eid);
		
		return "index";
		
	}
	
	public String insert(Employee emp) {
		
		
		obj.insertEmployee(emp);
		
		
		
		return "index";
		
		
		
		
	}

}


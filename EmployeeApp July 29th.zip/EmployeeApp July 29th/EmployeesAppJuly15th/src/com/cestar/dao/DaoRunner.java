package com.cestar.dao;

import com.cestar.model.Employee;

public class DaoRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmpDao obj = new EmpDao();
		
		Employee e = new Employee(111,"Fisher Hallman","Kitchener","Procurement","Fisher@gmail.com");

		obj.insertRecord(e);
	}

}

package com.faisal.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.faisal.model.Book;

public class BookDao {

	// Step-1 Create a database bookstore2 in mysql
	// Step-2 Create a table books2 in this database
	// Step-3 Write a method for connection
	// Step-4 Import interfaces and classes from java.sql package only

	public Connection getConnection() throws ClassNotFoundException, SQLException {

		// Load the driver for mysql database

		Class.forName("com.mysql.jdbc.Driver");

		// Create a Connection url

		String url = "jdbc:mysql://localhost:3306/bookstore2";

		String user = "root";

		String pwd = "";

		Connection con = DriverManager.getConnection(url, user, pwd);

		System.out.println("Connection Successfull:");

		return con;

	}

	public void display() throws ClassNotFoundException, SQLException {

		String sql = "select * from books2";

		Connection con = getConnection();

		Statement stmt = con.createStatement();

		ResultSet rs = stmt.executeQuery(sql);

		List<Book> books = new ArrayList<>();

		while (rs.next()) {

			Book book = new Book(rs.getInt(1), rs.getString(2), rs.getString(3));

			books.add(book);

		}

		System.out.println(books);

	}

	public void insert() throws ClassNotFoundException, SQLException {

		String sql = "insert into books2 values(146,'Java Collections','Yash Depak')";

		
		Connection con = getConnection();

		Statement stmt = con.createStatement();

		int status = stmt.executeUpdate(sql);

		if (status > 0) {
			System.out.println("Record Inseted Successfully:");
		} else {

			System.out.println("Try again:");
		}

	}

	public void insertDynamically() {
		
		Scanner sc = new Scanner(System.in);
		
		int ch = 0 ;
		
		while(ch!=1){
			
			System.out.println("Please enter 2 if you want to insert a book or 1 to exit! ");
			
			ch =sc.nextInt();
   
			if(ch==2){
			
		String sql = "insert into books2 values (?,?,?)";

		

		System.out.println("Please enter the id of the book:");

		int id = sc.nextInt();

		sc.nextLine(); // consume the space

		System.out.println("Please enter the name of the book:");

		String name = sc.nextLine();

		System.out.println("Please enter the name of the author:");

		String author = sc.nextLine();

		Connection con;
		try {
			con = getConnection();

			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, id);

			pstmt.setString(2, name);

			pstmt.setString(3, author);

			int status = pstmt.executeUpdate();

			if (status > 0) {

				System.out.println("Record Inserted Successfully:");

				display();
			}

			else {

				System.out.println("Sorry Try again:");
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		else {
			
			System.out.println("Thanks for using Application ,You may exit now:");
			System.exit(0);
		}
		}
	}

	public void delete() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter how many books to delete?");

		int num = sc.nextInt();

		for (int i = 1; i <= num; i++) {

			String sql = "delete from books2 where id=?";

			System.out.println("Please enter the ID of the book:");

			int id = sc.nextInt();

			try {

				Connection con = getConnection();

				PreparedStatement pstmt = con.prepareStatement(sql);

				pstmt.setInt(1, id);

				int status = pstmt.executeUpdate();

				if (status > 0) {

					System.out.println("Record Deleted Successfully:");
				} else {

					System.out.println("Please try again:");
				}

			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		System.out.println("You deleted  "+num+" " +"books");
	}
	
	public void update() throws ClassNotFoundException, SQLException{
		
		display();
		
		String sql = "update books2 set id=? , name=? , author=? where id=? ";
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter the id of the book to be updated:");
		
		int curr_id = sc.nextInt();
		
		System.out.println("Please enter the updated value for the ID:");
		
		int updated_id = sc.nextInt();
		
		sc.nextLine();
		
		System.out.println("Please enter the updated name for the book:");
		
		String updated_name = sc.nextLine();
		
		System.out.println("Please enter th updated Author Name for the book:");
		
		String updated_author = sc.nextLine();
		
		try {
			Connection con = getConnection();
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, updated_id);
			
			pstmt.setString(2, updated_name);
			
			pstmt.setString(3,updated_author);
			
			pstmt.setInt(4,curr_id);
			
			int status = pstmt.executeUpdate();
			
			if(status>0){
				
				System.out.println("Record Updated as below in the Table:");
				display();
			}
			else {
				
				System.out.println("Try Again Please:");
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}
}

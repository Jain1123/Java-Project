package com.cestar.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cestar.dao.EmployeeDao;
import com.cestar.model.Employee;

/**
 * Servlet implementation class SubmitServlet
 */
@WebServlet("/SubmitServlet")
public class SubmitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SubmitServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
	//	int curr_id = Integer.parseInt(request.getParameter("curr_id"));
		
		HttpSession session = request.getSession();
		
		int curr_id = (int) session.getAttribute("curr_id");
		
		out.print("curr_id="+curr_id);
		
		int id = Integer.parseInt(request.getParameter("e_id"));
		
		String name = request.getParameter("e_name");
		
		String contact = request.getParameter("e_contact");
		
		String city = request.getParameter("e_city");
		
		Employee  updated_emp = new Employee(id,name,contact,city);
		
		EmployeeDao obj = new EmployeeDao();
		
		obj.update(updated_emp, curr_id);
		
		response.sendRedirect("DisplayServlet");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

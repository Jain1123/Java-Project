package com.cestar.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cestar.dao.EmployeeDao;
import com.cestar.model.Employee;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		
		PrintWriter  out = response.getWriter();
		
		int curr_id = Integer.parseInt(request.getParameter("emp_id"));
		
		HttpSession session = request.getSession();
		
		session.setAttribute("curr_id",curr_id);
		
		
		
		EmployeeDao obj = new EmployeeDao();
		
		Employee emp = obj.getEmployeeById(curr_id);
		
		
		
		out.print("<html>");
		out.print("<body>");
		
		out.print("<form action='SubmitServlet'>");
		
		out.print("Employee ID:<input type='text'  name='e_id' value='"+emp.getId()+"'><br><br>");
		
		out.print("Name:<input type='text'  name='e_name' value='"+emp.getName()+"'><br><br>");
		
		out.print("Conatct :<input type='text'  name='e_contact' value='"+emp.getContact()+"'><br><br>");
		
		out.print("City:<input type='text'  name='e_city' value='"+emp.getCity()+"'><br><br>");
		
		out.print("<input type='submit' value='Update'>");
		
		
		out.print("</form>");
		out.print("</body>");
		out.print("</html>");
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

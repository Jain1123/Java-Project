package com.cestar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cestar.model.Employee;

public class EmployeeDao {

	public Connection getConnection() {

		Connection con = null;

		String url = "jdbc:mysql://localhost:3306/emps";

		String user = "root";

		String pwd = "";

		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection(url, user, pwd);

			System.out.println("Connection Successfull");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}

	public List<Employee> display() {

		List<Employee> list = new ArrayList<>();

		String sql = "select * from Employee";

		Connection con = getConnection();

		try {
			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				Employee emp = new Employee(rs.getInt("id"), rs.getString("name"), rs.getString("contact"),
						rs.getString("city"));

				list.add(emp);
			}
			System.out.println(list);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}

	public int delete(int id) {

		String sql = "delete  from Employee where id=?";

		Connection con = getConnection();

		int status = 0;

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, id);

			status = pstmt.executeUpdate();

			if (status > 0) {
				System.out.println("Record Deleted:");
			} else {
				System.out.println("Try Again Please:");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;

	}

	public Employee getEmployeeById(int id) {

		String sql = "select * from Employee where id=?";

		Employee emp = null;

		Connection con = getConnection();

		try {

			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				// emp = new
				// Employee(rs.getInt("id"),rs.getString("name"),rs.getString("contact"),rs.getString("city"));

				emp = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}

			System.out.println(emp);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;

	}
	
	public int update(Employee updated_emp,int curr_id){
		
		
		String sql ="update Employee set id=?,name=?,contact=?,city=? where id=?";
		
		Connection con= getConnection();
		
		int status = 0;
		
		try {
			
			PreparedStatement pstmt = con.prepareStatement(sql);
		
		    pstmt.setInt(1,updated_emp.getId() );
		    pstmt.setString(2,updated_emp.getName());
		    pstmt.setString(3, updated_emp.getContact());
		    pstmt.setString(4, updated_emp.getCity());
		    
		    pstmt.setInt(5, curr_id);
		    
		     status = pstmt.executeUpdate();
		
		     if(status>0){
		    	 System.out.println("Record Updated:");
		     }
		     else {
		    	 
		    	 System.out.println("Try Again Please:");
		     }
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
		
		
		
		
		
		
		
		
		
		
	}

}

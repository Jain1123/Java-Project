package com.cestar.dao;

public class DaoRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmployeeDao obj = new EmployeeDao();
		
		obj.getEmployeeById(98);

	}

}

package com.cestar.dao;

import java.util.Scanner;

//import java.util.Scanner;

public class DaoRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		PatientDao pt = new PatientDao(); // create an object to access PatientDao class

        Scanner sc = new Scanner(System.in);
		
		int ch = 0 ;
		
		while(ch!=1){
			
			System.out.println("choose the following options: "
					+ "1) press '2' to insert new data, "
					+ "2) press '3' to update exsiting data, "
					+ "3) press '4' to delete data or "
					+ "4) press '5' to display data, "
					+ "5) press 1 to exit");
			
			ch =sc.nextInt();
   
			if(ch==2){
				
				pt.insertDynamically();
			}
			else if(ch==3)
			{
			pt.updateData();	
			}
			else if(ch==4)
			{
				pt.deleteData();
			}
			else if(ch==5)
			{
				pt.display();
			}
			else
			{
				System.out.println("Thanks for using Patient Record app..!!! You may exit now.");
			}
			
		}
	}
}

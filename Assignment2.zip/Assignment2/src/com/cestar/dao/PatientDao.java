package com.cestar.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PatientDao {
	public Connection getConnection()  {

		String url = "jdbc:mysql://localhost:3306/patientrecords"; //patientrecords is name of database

		String user = "root";

		String pwd = "";

		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");   // Load the driver for mysql database
			
			 con = DriverManager.getConnection(url, user, pwd);

			System.out.println("Connection Successful:");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
		
	
	public void display()
	{
		List <String> pat = new ArrayList<String>();
		
		String sql = "select * from patient"; // select query used to retreive all fields of data from table named patient 
		Connection con = getConnection();
		try {
						
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			//List<PatientModel> patient = new ArrayList<>();
			while(rs.next())
			{
               String pt = new String("\n"+"Patient Id= "+rs.getInt(1)+",Name= "+rs.getString(2)+",Contact= "+
			   rs.getString(3)+",Region= "+rs.getString(4)+",Disease= "+rs.getString(5)+",Medicine Prescribed= "+
               rs.getString(6)+",Visit Date= "+rs.getString(7)+",Doctor Name= "+rs.getString(8)+"\n");
		       pat.add(pt);
							
			}
			System.out.println(pat);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
	
	
	
        public void insertDynamically() {
		
		//Scanner sc = new Scanner(System.in);
		
	//	int ch = 0 ;
		
		//while(ch!=1){
			
			//System.out.println("If you want to insert a book, please press 2 otherwise press 1 to exit! ");
			
			//ch =sc.nextInt();
   
			//if(ch==2){
			
		//String sql = "insert into patient values (?,?,?,?,?,?,?,?)";

		//System.out.println("Please enter the id of the Patient:");

		//int id = sc.nextInt();

		//sc.nextLine(); // consume the space

		//System.out.println("Please enter the name of the Patient:");

		//String name = sc.nextLine();

		//System.out.println("Please enter the Contact number:");

		//String contact = sc.nextLine();
		
		//System.out.println("Please enter the Region:");

		//String region = sc.nextLine();
		
	//	System.out.println("Please enter the name of Disease:");

		//String disease = sc.nextLine();
		
		//System.out.println("Please enter the Prescribed medicine for particular disease:");

		//String medicine = sc.nextLine();
		
		//System.out.println("Please enter the visit date:");

		//String date = sc.nextLine();
		
		//System.out.println("Please enter the name of doctor:");

		//String doctor = sc.nextLine();
		
		Connection con;
		try {
			con = getConnection();
			
			String sql = "insert into patient values (?,?,?,?,?,?,?,?);";
			
			Scanner sc= new Scanner(System.in);
			
			System.out.println("Enter the new patient id: ");
			
			int id = sc.nextInt();
			sc.nextLine();
			
			System.out.println("Enter the name of new patient: ");
			
			String name = sc.nextLine();
			
			System.out.println("Enter the contact number: ");
			
			String contact = sc.nextLine();
			
			System.out.println("Enter the name of region: ");
			
			String region = sc.nextLine();
			
			System.out.println("Enter the name of disease: ");
			
			String disease = sc.nextLine();
			
			System.out.println("Enter the name of prescribed medicine: ");
			
			String medicine = sc.nextLine();
			
			System.out.println("Enter the visit date: ");
			
			String date = sc.nextLine();
			
			System.out.println("Enter the name of doctor: ");
			
			String doctor = sc.nextLine();

			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, id);

			pstmt.setString(2, name);

			pstmt.setString(3, contact);
			
			pstmt.setString(4, region);
			
			pstmt.setString(5, disease);
			
			pstmt.setString(6, medicine);
			
			pstmt.setString(7, date);
			
			pstmt.setString(8, doctor);

			int status = pstmt.executeUpdate();

			if (status > 0) {

				System.out.println("Record is inserted Successfully:");

                System.out.println("Updated table with new record: "); 
				
				this.display();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		
        
        
        public void updateData() {
    		
    		display();
    		
    		String sql = "update patient set patientid=? , name=? , contact=?, region=?, disease=?, medicine_prescribed=?, visit_date=?, doctor_name=? where patientid=? ";
    		
    		Scanner sc = new Scanner(System.in);
    		
    		System.out.println("Please enter the id of the patient:");
    		
    		int curr_id = sc.nextInt();
    		
    		System.out.println("Please enter the updated value for patient ID:");
    		
    		int updated_id = sc.nextInt();
    		
    		sc.nextLine();
    		
    		System.out.println("Please enter the updated name for the patient:");
    		
    		String updated_name = sc.nextLine();
    		
    		System.out.println("Please enter the updated contact number:");
    		
    		String updated_contact = sc.nextLine();
    		
    		System.out.println("Please enter the updated Region:");
    		
    		String updated_region = sc.nextLine();
    		
    		System.out.println("Please enter the updated Disease:");
    		
    		String updated_disease = sc.nextLine();
    		
    		System.out.println("Please enter the updated prescribed medicine for updated disease:");
    		
    		String updated_medicine = sc.nextLine();
    		
    		System.out.println("Please enter the updated visit date:");
    		
    		String updated_date = sc.nextLine();
    		
    		System.out.println("Please enter the updated name of doctor:");
    		
    		String updated_doctor = sc.nextLine();
    			
    		try {
    			Connection con = getConnection();
    			
    			PreparedStatement pstmt = con.prepareStatement(sql);
    			
    			pstmt.setInt(1, updated_id);
    			
    			pstmt.setString(2, updated_name);
    			
    			pstmt.setString(3,updated_contact);
    			
    			pstmt.setString(4,updated_region);
    			
    			pstmt.setString(5,updated_disease);
    			
    			pstmt.setString(6,updated_medicine);
    			
    			pstmt.setString(7,updated_date);
    			
    			pstmt.setString(8,updated_doctor);
    			    			
    			pstmt.setInt(9,curr_id);
    			
    			int status = pstmt.executeUpdate();
    			
    			if(status>0){
    				
    				System.out.println("Record Updated successfully:");
    				display();
    			}
    			else {
    				
    				System.out.println("Try Again,Please:");
    			}
    			
    			
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    		    		
    	}
        
        
        public void deleteData() {

    		Scanner sc = new Scanner(System.in);

    		System.out.println("Please enter number of patient records you want to delete?");

    		int num = sc.nextInt();

    		for (int i = 1; i <= num; i++) {

    			String sql = "delete from patient where patientid=?";

    			System.out.println("Please enter the ID of the patient:");

    			int id = sc.nextInt();

    			try {

    				Connection con = getConnection();

    				PreparedStatement pstmt = con.prepareStatement(sql);

    				pstmt.setInt(1, id);

    				int status = pstmt.executeUpdate();

    				if (status > 0) {

    					System.out.println("You deleted record successfully!!!");
    				} else {

    					System.out.println("Please try again:");
    				}

    			} catch (SQLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}

    		}
    		System.out.println("You deleted  "+num+" " +"patient");
    	}
}

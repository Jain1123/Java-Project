package com.cestar.model;

public class PatientModel {

	private int Patientid;
	private String Name;
	private String Contact;
	private String Region;
	private String Disease;
	private String Medicine_Prescribed;
	private String Visit_Date;
	private String Doctor_Name;
	
		
	public int getPatientid() {
		return Patientid;
	}
	public void setPatientid(int patientid) {
		this.Patientid = patientid;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		this.Contact = contact;
	}
	public String getRegion() {
		return Region;
	}
	public void setRegion(String region) {
		this.Region = region;
	}
	public String getDisease() {
		return Disease;
	}
	public void setDisease(String disease) {
		this.Disease = disease;
	}
	public String getMedicine_Prescribed() {
		return Medicine_Prescribed;
	}
	public void setMedicine_Prescribed(String medicine_Prescribed) {
		this.Medicine_Prescribed = medicine_Prescribed;
	}
	public String getVisit_Date() {
		return Visit_Date;
	}
	public void setVisit_Date(String visit_Date) {
		this.Visit_Date = visit_Date;
	}
	public String getDoctor_Name() {
		return Doctor_Name;
	}
	public void setDoctor_Name(String doctor_Name) {
		this.Doctor_Name = doctor_Name;
	}
	public PatientModel(int patientid, String name, String contact, String region, String disease,
			String medicine_Prescribed, String visit_Date, String doctor_Name) {
		super();
		this.Patientid = patientid;
		this.Name = name;
		this.Contact = contact;
		this.Region = region;
		this.Disease = disease;
		this.Medicine_Prescribed = medicine_Prescribed;
		this.Visit_Date = visit_Date;
		this.Doctor_Name = doctor_Name;
	}
	@Override
	public String toString() {
		return "PatientModel [Patientid=" + Patientid + ", Name=" + Name + ", Contact=" + Contact + ", Region=" + Region
				+ ", Disease=" + Disease + ", Medicine_Prescribed=" + Medicine_Prescribed + ", Visit_Date=" + Visit_Date
				+ ", Doctor_Name=" + Doctor_Name + "+'/n']";
	}
		
}

package com.cestar.dao;

import com.cestar.model.Employee;

public class DaoRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmpDao obj = new EmpDao();
		
		Employee e_updated = new Employee(889,"King Bruce","Dtroit","IT","King@yahoo.com");
		
		int old_id = 543 ;
		
		obj.updateRecord(e_updated, old_id);

	}

}

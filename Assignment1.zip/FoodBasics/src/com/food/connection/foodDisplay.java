package com.food.connection;

public class foodDisplay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FoodDao food = new FoodDao();
		food.getConnection();
		food.display();
	
	}

}

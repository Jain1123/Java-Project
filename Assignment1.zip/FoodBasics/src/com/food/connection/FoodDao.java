package com.food.connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FoodDao {
	public Connection getConnection() {
	Connection con =null;
	String url = "jdbc:mysql://localhost:3306/foodbasics";
	String user="root";
	String pass= "";
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con= DriverManager.getConnection(url,user,pass);
		
		System.out.println("Connection Successful");
	} catch (ClassNotFoundException f) {
		// TODO Auto-generated catch block
		f.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return con;
}
  public void display() {
	List <String> v = new ArrayList<String>();
	String sql = "Select * from items";
	Connection con = getConnection();
	try {
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()) {
			String f = new String("id=" + rs.getInt("product_id") + "  name=" +rs.getString("product_name") +"	date="+ rs.getDate("entry_date") +"	 region="+ rs.getString("region") +" sales Person="+ rs.getString("sales_person") +"  price="+ rs.getInt("price")+ "\n");
			v.add(f);
			
		}
		System.out.println(v);
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}

package com.food.connection;

import java.sql.Date;

public class FoodModel {
	private int product_id;
	private String product_name;
	private Date entry_date;
	private String region;
	private String sales_person;
	private String price;
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public Date getEntry_date() {
		return entry_date;
	}
	public void setEntry_date(Date entry_date) {
		this.entry_date = entry_date;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getSales_person() {
		return sales_person;
	}
	public void setSales_person(String sales_person) {
		this.sales_person = sales_person;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public FoodModel(int product_id, String product_name, Date entry_date, String region, String sales_person,
			String price) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.entry_date = entry_date;
		this.region = region;
		this.sales_person = sales_person;
		this.price = price;
	}
	@Override
	public String toString() {
		return "FoodModel [product_id=" + product_id + ", product_name=" + product_name + ", entry_date=" + entry_date
				+ ", region=" + region + ", sales_person=" + sales_person + ", price=" + price + "]";
	}
	
}

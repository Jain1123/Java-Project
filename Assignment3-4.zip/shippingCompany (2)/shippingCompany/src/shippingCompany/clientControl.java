package shippingCompany;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class clientControl
 */
@WebServlet("/")
public class clientControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public clientControl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = request.getServletPath();
		response.setContentType("text/html");
		PrintWriter print = response.getWriter();
		switch(url) {
		case "/display":{
			display(request,response);
			break;
		}
		case "/update":{
			
			try {
				update(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		  case "/edit":
		     {
		    	 try {
					edit(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	 break;
		    	 
		     }
		  case "/delete":
		     {
		    	 try {
					delete(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	 break;
		    	 
		     }
		     
		     case "/insert":
		     {
		    	 
		    	 try {
					insert(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	 break;
		     }
		default:{
			System.out.println("Sorry required page is not avaialable");
		}
		}
	}

	private void insert(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		// TODO Auto-generated method stub
		int id = Integer.parseInt(request.getParameter("c_id")); 
		 
		 String name = request.getParameter("c_name");
		 
		 String contact = request.getParameter("c_contact");
		 
		 String item = request.getParameter("c_itemshipped");
		 
		 String receive = request.getParameter("c_daterecived");
		 
		 String ship = request.getParameter("c_dateshipped");
		 
		 ClientModel clint = new ClientModel(id,name,contact,item,receive,ship);
		 
		 clientDao obj1 = new clientDao();
		 
		 obj1.insertRecord(clint);
		 
		 
		 display(request, response);
		
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		// TODO Auto-generated method stub
		int c_id = Integer.parseInt(request.getParameter("c_id"));
		
		clientDao obj2 = new clientDao();
		
		obj2.deleteRecord(c_id);
		
		display(request, response);
	}

	private void edit(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		// TODO Auto-generated method stub
		clientDao obj = new clientDao();
		
		int id = Integer.parseInt(request.getParameter("e_id"));
		
		ClientModel clint = obj.getRecordById(id);
		
		HttpSession session = request.getSession();
		
		session.setAttribute("clint", clint);
		
		session.setAttribute("old_id", id);
		
		response.sendRedirect("update.jsp");
	}

	private void update(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		// TODO Auto-generated method stub
		int c_id = Integer.parseInt(request.getParameter("c_id"));
		
		String c_name = request.getParameter("c_name");
		
		String c_contact = request.getParameter("c_contact");
		
		String c_itemshipped = request.getParameter("c_itemshipped");
		
		String c_datereceived = request.getParameter("c_daterecived");
		
		String c_dateshipped = request.getParameter("c_dateshipped");
		
		ClientModel updated_client = new ClientModel(c_id, c_name, c_contact, c_itemshipped, c_datereceived, c_dateshipped);
		
		HttpSession session = request.getSession();
		
	    int old_id = (int)session.getAttribute("old_id");
	
		clientDao obj = new clientDao();
		
		obj.updateRecord(updated_client, old_id);
		
		display(request,response);
	}

	private void display(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println("helllllooooo");
		// TODO Auto-generated method stub
		clientDao obj = new clientDao();
		List<ClientModel> client= obj.displayAllRecords();
		HttpSession session= request.getSession();
		session.setAttribute("client", client);
		response.sendRedirect("display.jsp");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

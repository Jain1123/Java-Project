package shippingCompany;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class clientDao {
	public Connection getConnection() throws SQLException{
		System.out.println("entered connection");
		String url = "jdbc:mysql://localhost:3306/shippingrecords";
		String user = "root";
		String pwd = "";
		Connection con = null;
		
		try {
	       Class.forName("com.mysql.jdbc.Driver");
			
			con = DriverManager.getConnection(url,user,pwd);
			
			System.out.println("Connection successfull:");
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	public List<ClientModel> displayAllRecords(){
		List<ClientModel> client= new ArrayList<>();
		String sql = "Select * from clients";
		try {
			Connection con = getConnection();
			Statement stmt = con.createStatement();
			ResultSet res = stmt.executeQuery(sql);
			while(res.next()) {
				ClientModel clientModel= new ClientModel(res.getInt(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5),res.getString(6));
				client.add(clientModel);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(client);
		return client;
	}
	//GetRecords--------------------------------------------------------------->
	public ClientModel getRecordById(int c_id) throws SQLException {
		Connection con = getConnection();
		
		String sql = "select * from clients where clientid=?";
		
		ClientModel clint = null ;
		
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,c_id );
			
			ResultSet res = pstmt.executeQuery();
			if(res.next()) {
				
				clint  = new ClientModel(res.getInt(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5),res.getString(6));
			}
			 System.out.println(clint);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return clint;
		
	}
	
	//update----------------------------------------------------------------->
		public void updateRecord(ClientModel updated_clint,int old_id) throws SQLException {
		
		Connection con = getConnection();
		
		String sql = "update clients set clientid=?,name=?,contact=?,itemshipped=?,daterecived=?,dateshipped=? where clientid=?";
		
		int status = 0 ;
		
		try {
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1,updated_clint.getClientid());
			
			pstmt.setString(2, updated_clint.getName());
			
			pstmt.setString(3, updated_clint.getContact());
			
			pstmt.setString(4, updated_clint.getItemshipped());
			
			pstmt.setString(5, updated_clint.getDaterecived());
			
			pstmt.setString(6, updated_clint.getDateshipped());
			
			pstmt.setInt(7, old_id);
			
			status = pstmt.executeUpdate();
			
			if(status>0) {
				
				System.out.println("Record Updated:");
			}
			else {
				
				System.out.println("Try again:");
			}
		
		
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		//Delete--------------------------------------------------->
		public void deleteRecord(int c_id) throws SQLException {

			Connection con = getConnection();

			String sql = "delete from clients where clientid=?";

			int status = 0;

			try {
				PreparedStatement pstmt = con.prepareStatement(sql);

				pstmt.setInt(1, c_id);

				status = pstmt.executeUpdate();

				if (status > 0) {

					System.out.println("Record Deleted");
				} else {
					System.out.println("Try Again Please:");
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}
		//INSERT ------------------------------->
		public void insertRecord(ClientModel clint) throws SQLException {
			
			Connection con = getConnection();
			
			String sql = "insert into clients values (?,?,?,?,?,?)";
			
			int status = 0 ;
			
			try {
				
				PreparedStatement pstmt = con.prepareStatement(sql);
			
				pstmt.setInt(1, clint.getClientid());
				
				pstmt.setString(2,clint.getName());
				
				pstmt.setString(3,clint.getContact());
				
				pstmt.setString(4, clint.getItemshipped());
				
				pstmt.setString(5, clint.getDaterecived());
				
				pstmt.setString(6, clint.getDateshipped());
				
				status = pstmt.executeUpdate();
			
				if(status>0) {
					
					System.out.println("Record Inserted:");
				}
				
				else {
					
					System.out.println("Try again please:");
				}
			
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	
}}
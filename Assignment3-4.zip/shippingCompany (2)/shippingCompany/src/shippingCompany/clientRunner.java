package shippingCompany;

public class clientRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("111");
		clientDao obj = new clientDao();
		obj.displayAllRecords();
		
	}

}

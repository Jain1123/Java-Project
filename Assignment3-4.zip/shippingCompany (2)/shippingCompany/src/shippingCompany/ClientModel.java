package shippingCompany;

public class ClientModel {
private int clientid;
private String name;
private String contact;
private String itemshipped;
private String daterecived;
private String dateshipped;
public int getClientid() {
	return clientid;
}
public void setClientid(int clientid) {
	this.clientid = clientid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}
public String getItemshipped() {
	return itemshipped;
}
public void setItemshipped(String itemshipped) {
	this.itemshipped = itemshipped;
}
public String getDaterecived() {
	return daterecived;
}
public void setDaterecived(String daterecived) {
	this.daterecived = daterecived;
}
public String getDateshipped() {
	return dateshipped;
}
public void setDateshipped(String dateshipped) {
	this.dateshipped = dateshipped;
}
public ClientModel(int clientid, String name, String contact, String itemshipped, String daterecived,
		String dateshipped) {
	super();
	this.clientid = clientid;
	this.name = name;
	this.contact = contact;
	this.itemshipped = itemshipped;
	this.daterecived = daterecived;
	this.dateshipped = dateshipped;
}
@Override
public String toString() {
	return "ClientModel [clientid=" + clientid + ", name=" + name + ", contact=" + contact + ", itemshipped="
			+ itemshipped + ", daterecived=" + daterecived + ", dateshipped=" + dateshipped + "]";
}

}

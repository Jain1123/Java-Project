package com.cestar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cestar.model.Employee;

public class EmployeeDao {
	
	
	public Connection getConnection() {

		String url = "jdbc:mysql://localhost:3306/emps";

		String user = "root";

		String pwd = "";

		Connection con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection(url, user, pwd);

			System.out.println("Connection successfull:");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}

	public List<Employee> displayAllEmployees() {

		List<Employee> employees = new ArrayList<>();

		String sql = "select * from employees";

		Connection con = getConnection();

		try {
			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				int id = rs.getInt(1);

				String name = rs.getString(2);

				String city = rs.getString(3);

				String dept = rs.getString(4);

				String email = rs.getString(5);

				Employee emp = new Employee(id, name, city, dept, email);

				employees.add(emp);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(employees);

		return employees;

	}
	
	public int deleteEmployee(int empIdTobeDeleted){
		
		Connection con = getConnection();
		
		int status = 0 ;
		
		String sql = "delete  from employees where id=?;";
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, empIdTobeDeleted);
			
			 status = pstmt.executeUpdate();
			
			if(status>0){
				System.out.println("Employee Deleted");
			}
			else {
				
				System.out.println("Try again dear:");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}
	
	public int insertEmployee(Employee emp){
		
		
		Connection con = getConnection();
		
		int status = 0 ;
		
		String sql = "insert into employees values(?,?,?,?,?)";
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1,emp.getId());
			
			pstmt.setString(2,emp.getName());
			
			pstmt.setString(3,emp.getCity());
			
			pstmt.setString(4,emp.getDepartment());
			
			pstmt.setString(5,emp.getEmail());
			
		     status = pstmt.executeUpdate();
			
			if(status>0){
				
				System.out.println("Record Inserted successfully:");
			}
			else {
				
				System.out.println("Record not Inserted:");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
		
		
		
		
	}
	
	public Employee getEmployeeById(int curr_id){
		
		
		Connection con = getConnection();
		
		String sql = "select * from employees where id=?;";
		
		Employee   emp = new Employee();
		
		try {
			
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, curr_id);
			
			ResultSet rs =    pstmt.executeQuery();
			
			while(rs.next()){
				
				int id = rs.getInt(1);
				
				String name = rs.getString(2);
				
				String city = rs.getString(3);
				
				String dept = rs.getString(4);
				
				String email = rs.getString(5);
				
				emp.setId(id);
				emp.setName(name);
				emp.setCity(city);
				emp.setDepartment(dept);
				emp.setEmail(email);
				
				
				
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
		
		
		
		
	}
	
	public int updateEmployee(int curr_id,Employee updated_emp){
		
		
		Connection con = getConnection();
		
		int status = 0 ;
		
		String sql = "update employees set id=? , name =? ,city=? , department=? ,email =? where id=?";
		
	//	"update employees set id=? , name =? ,city=? , department=? ,email =? where id=?"
		
		try {
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1,updated_emp.getId());
			
			pstmt.setString(2,updated_emp.getName());
			
			pstmt.setString(3,updated_emp.getCity());
			
			pstmt.setString(4,updated_emp.getDepartment());
			
			pstmt.setString(5,updated_emp.getEmail());
			
			pstmt.setInt(6,curr_id);
			
		    status = pstmt.executeUpdate();
			
			if(status>0){
				
				System.out.println("Record Updated:");
			}
			else {
				
				System.out.println("Try again:");
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return status ;
		
		
	}

	
	

}
	



package com.cestar.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cestar.dao.EmployeeDao;
import com.cestar.model.Employee;

@Path("employees") 
public class EmployeeResource {
	
	EmployeeDao  obj = new EmployeeDao();
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Employee> displayAll(){
		
		List<Employee> emps = obj.displayAllEmployees();
		
		return emps;
		
		
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{eid}")
	public Employee getEmployee(@PathParam("eid")  int id) {
		
		
		Employee emp = obj.getEmployeeById(id);
		
		return emp;
		
		
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("insert")
	public String insert(Employee emp) {
		
		int status = obj.insertEmployee(emp);
		
		if(status<0) {
			return "Record not inserted";
		}
		else {
			
			return "Record inserted successfully!!!";
		}
	}
	
	
	@DELETE
	@Path("delete/{eid}")
	public String deleteEmployee(@PathParam("eid")  int id) {
		
		
		int status = obj.deleteEmployee(id);
		
		if(status<0) {
			
			return "Record not Deleted!!!";
		}
		else {
			
			return "Record Deleted Successfully";
		}
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("update/{eid}")
	public String updateEmployee(@PathParam("eid")  int id,Employee updatedEmp) {
		
		int status = obj.updateEmployee(id, updatedEmp);
		
    if(status<0) {
			
			return "Record not Updated!!!";
		}
		else {
			
			return "Record Updated Successfully!!!";
		}
		
	}
	

}
